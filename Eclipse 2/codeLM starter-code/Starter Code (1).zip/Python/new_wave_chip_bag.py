def new_wave_chip_bag(weight, new_wave_special_value):
  # Your code here


if __name__ == '__main__':
  weight = int(input())
  new_wave_special_value = float(input())

  function_call_result = new_wave_chip_bag(weight, new_wave_special_value)
  print(function_call_result)
