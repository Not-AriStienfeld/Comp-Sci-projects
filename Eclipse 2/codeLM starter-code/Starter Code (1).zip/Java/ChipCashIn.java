import java.util.Scanner;

class ChipCashIn {
    static double chipCashIn(int totalChipValue) {
        // Your code here
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        int totalChipValue = Integer.parseInt(s.nextLine());

        double functionCallResult = chipCashIn(totalChipValue);
        System.out.println(functionCallResult);
    }
}