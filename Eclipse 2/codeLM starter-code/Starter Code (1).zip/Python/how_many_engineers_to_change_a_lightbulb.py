def how_many_engineers_to_change_a_lightbulb(position):
  # Your code here


if __name__ == '__main__':
  position = int(input())

  function_call_result = how_many_engineers_to_change_a_lightbulb(position)
  print(function_call_result)
