def club_crazy(jack_cards, diane_cards):
  # Your code here


if __name__ == '__main__':
  jack_cards = input()
  diane_cards = input()

  function_call_result = club_crazy(jack_cards, diane_cards)
  print(function_call_result)
