#include <iostream>

using namespace std;

int main() {
  string x;
  getline(cin, x);
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}