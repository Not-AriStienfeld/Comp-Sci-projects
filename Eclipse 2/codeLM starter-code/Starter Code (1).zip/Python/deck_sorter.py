def deck_sorter(deck):
  # Your code here


if __name__ == '__main__':
  deck = input()

  function_call_result = deck_sorter(deck)
  print(function_call_result)
