#include <iostream>

using namespace std;

int main() {
  int givenSlotRow;
  cin >> givenSlotRow;
  int givenSlotCol;
  cin >> givenSlotCol;
  char givenSlot[givenSlotRow][givenSlotCol];
  for (int i = 0; i < givenSlotRow; i++) {
    for (int j = 0; j < givenSlotCol; j++) {
      cin >> givenSlot[i][j];
    }
  }
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  int resultLength = sizeof(result) / sizeof(result[0]);
  for (int i = 0; i < resultLength; i++) {
    int resultLengthInner = sizeof(result[i]) / sizeof(result[i][0]);
    for (int j = 0; j < resultLengthInner; j++) {
      cout << result[i][j] << " ";
    }
    cout << endl;
  }
}