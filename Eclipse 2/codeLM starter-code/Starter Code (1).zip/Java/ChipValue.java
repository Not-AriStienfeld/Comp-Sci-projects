import java.util.Scanner;

class ChipValue {
    static int chipValue(int redValue, int blackValue, int greenValue, int yellowValue, int whiteValue, int redAmount, int blackAmount, int greenAmount, int yellowAmount, int whiteAmount, int totalValueOfChips) {
        // Your code here
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        int redValue = Integer.parseInt(s.nextLine());
        int blackValue = Integer.parseInt(s.nextLine());
        int greenValue = Integer.parseInt(s.nextLine());
        int yellowValue = Integer.parseInt(s.nextLine());
        int whiteValue = Integer.parseInt(s.nextLine());
        int redAmount = Integer.parseInt(s.nextLine());
        int blackAmount = Integer.parseInt(s.nextLine());
        int greenAmount = Integer.parseInt(s.nextLine());
        int yellowAmount = Integer.parseInt(s.nextLine());
        int whiteAmount = Integer.parseInt(s.nextLine());
        int totalValueOfChips = Integer.parseInt(s.nextLine());

        int functionCallResult = chipValue(redValue, blackValue, greenValue, yellowValue, whiteValue, redAmount, blackAmount, greenAmount, yellowAmount, whiteAmount, totalValueOfChips);
        System.out.println(functionCallResult);
    }
}