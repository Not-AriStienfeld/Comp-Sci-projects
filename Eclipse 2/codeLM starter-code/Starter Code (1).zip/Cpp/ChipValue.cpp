#include <iostream>

using namespace std;

int main() {
  int redValue;
  cin >> redValue;
  int blackValue;
  cin >> blackValue;
  int greenValue;
  cin >> greenValue;
  int yellowValue;
  cin >> yellowValue;
  int whiteValue;
  cin >> whiteValue;
  int redAmount;
  cin >> redAmount;
  int blackAmount;
  cin >> blackAmount;
  int greenAmount;
  cin >> greenAmount;
  int yellowAmount;
  cin >> yellowAmount;
  int whiteAmount;
  cin >> whiteAmount;
  int totalValueOfChips;
  cin >> totalValueOfChips;
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}