def chip_value(red_value, black_value, green_value, yellow_value, white_value, red_amount, black_amount, green_amount, yellow_amount, white_amount, total_value_of_chips):
  # Your code here


if __name__ == '__main__':
  red_value = int(input())
  black_value = int(input())
  green_value = int(input())
  yellow_value = int(input())
  white_value = int(input())
  red_amount = int(input())
  black_amount = int(input())
  green_amount = int(input())
  yellow_amount = int(input())
  white_amount = int(input())
  total_value_of_chips = int(input())

  function_call_result = chip_value(red_value, black_value, green_value, yellow_value, white_value, red_amount, black_amount, green_amount, yellow_amount, white_amount, total_value_of_chips)
  print(function_call_result)
