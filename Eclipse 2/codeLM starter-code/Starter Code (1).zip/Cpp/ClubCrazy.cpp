#include <iostream>

using namespace std;

int main() {
  string jackCards;
  getline(cin, jackCards);
  string dianeCards;
  getline(cin, dianeCards);
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}