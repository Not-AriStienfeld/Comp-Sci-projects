import java.util.Scanner;

class SocialMedia {
    static String socialMedia(String x) {
        // Your code here
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        String x = s.nextLine();

        String functionCallResult = socialMedia(x);
        System.out.println(functionCallResult);
    }
}