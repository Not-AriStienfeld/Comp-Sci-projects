import java.util.Scanner;

class DeckSorter {
    static String deckSorter(String deck) {
        // Your code here
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        String deck = s.nextLine();

        String functionCallResult = deckSorter(deck);
        System.out.println(functionCallResult);
    }
}