#include <iostream>

using namespace std;

int main() {
  string deck;
  getline(cin, deck);
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}