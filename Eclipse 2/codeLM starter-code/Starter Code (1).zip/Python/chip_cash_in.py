def chip_cash_in(total_chip_value):
  # Your code here


if __name__ == '__main__':
  total_chip_value = int(input())

  function_call_result = chip_cash_in(total_chip_value)
  print(function_call_result)
