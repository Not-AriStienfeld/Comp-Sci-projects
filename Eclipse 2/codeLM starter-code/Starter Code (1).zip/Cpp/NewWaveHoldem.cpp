#include <iostream>

using namespace std;

int main() {
  int handLength;
  cin >> handLength;
  string hand[handLength];
  for (int i = 0; i < handLength; i++) {
    cin >> ws; getline(cin, hand[i]);
  }
  int communityCardsLength;
  cin >> communityCardsLength;
  string communityCards[communityCardsLength];
  for (int i = 0; i < communityCardsLength; i++) {
    cin >> ws; getline(cin, communityCards[i]);
  }
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}