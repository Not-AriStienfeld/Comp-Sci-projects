def social_media(x):
  # Your code here


if __name__ == '__main__':
  x = input()

  function_call_result = social_media(x)
  print(function_call_result)
