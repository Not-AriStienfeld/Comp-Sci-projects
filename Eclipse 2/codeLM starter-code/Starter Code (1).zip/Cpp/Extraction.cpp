#include <iostream>

using namespace std;

int main() {
  int casinoFloorRow;
  cin >> casinoFloorRow;
  int casinoFloorCol;
  cin >> casinoFloorCol;
  char casinoFloor[casinoFloorRow][casinoFloorCol];
  for (int i = 0; i < casinoFloorRow; i++) {
    for (int j = 0; j < casinoFloorCol; j++) {
      cin >> casinoFloor[i][j];
    }
  }
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  int resultLength = sizeof(result) / sizeof(result[0]);
  for (int i = 0; i < resultLength; i++) {
    int resultLengthInner = sizeof(result[i]) / sizeof(result[i][0]);
    for (int j = 0; j < resultLengthInner; j++) {
      cout << result[i][j] << " ";
    }
    cout << endl;
  }
}