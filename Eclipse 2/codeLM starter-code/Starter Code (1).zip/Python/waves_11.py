def waves_11(encryption_key, encrypted_password):
  # Your code here


if __name__ == '__main__':
  encryption_key = int(input())
  encrypted_password = input()

  function_call_result = waves_11(encryption_key, encrypted_password)
  print(function_call_result)
