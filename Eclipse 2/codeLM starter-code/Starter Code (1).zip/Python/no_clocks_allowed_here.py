def no_clocks_allowed_here(first_hour_glass, second_hour_glass, timer):
  # Your code here


if __name__ == '__main__':
  first_hour_glass = int(input())
  second_hour_glass = int(input())
  timer = int(input())

  function_call_result = no_clocks_allowed_here(first_hour_glass, second_hour_glass, timer)
  print(function_call_result)
