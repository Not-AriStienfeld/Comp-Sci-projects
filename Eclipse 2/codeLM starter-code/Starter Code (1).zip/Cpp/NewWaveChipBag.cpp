#include <iostream>

using namespace std;

int main() {
  int weight;
  cin >> weight;
  double newWaveSpecialValue;
  cin >> newWaveSpecialValue;
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}