#include <iostream>

using namespace std;

int main() {
  int tablesLength;
  cin >> tablesLength;
  string tables[tablesLength];
  for (int i = 0; i < tablesLength; i++) {
    cin >> ws; getline(cin, tables[i]);
  }
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}