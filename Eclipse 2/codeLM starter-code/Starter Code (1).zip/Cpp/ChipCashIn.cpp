#include <iostream>

using namespace std;

int main() {
  int totalChipValue;
  cin >> totalChipValue;
  
  // BEGIN: your code
  // Name the variable that contains the answer `result`.
  
  // END: your code

  cout << result;
}